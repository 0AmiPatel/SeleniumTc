package com.automationtesting.mavenproject;

import org.openqa.selenium.By;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

public class SearchProduct extends Utils {



    @Test
    public void searchProduct(){            //(2)user should be able to search the product laptop using search functionality.

        System.setProperty("webdriver.gecko.driver", "src\\test\\Resources\\BrowserDriver\\geckodriver.exe");   //seting geckodriver path required to open the browser.
        driver = new FirefoxDriver();                         //created object of webdriver - firefox
        driver.get("http://demo.nopcommerce.com");


        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        enterValue(By.id("small-searchterms"),"Laptop");
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        clickElement(By.className("search-box-button"));

    }
    @Test
    public void verifySearchProductComplete(){
        String expectedUrl = "http://demo.nopcommerce.com/search?q=Laptop";
        String actualUrl = driver.getCurrentUrl();
        Assert.assertTrue(actualUrl.contains(expectedUrl),"Actual result doesn't match with expected for searchproduct");
    }

}
