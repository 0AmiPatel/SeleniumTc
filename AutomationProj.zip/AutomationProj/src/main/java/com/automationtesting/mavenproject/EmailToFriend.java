package com.automationtesting.mavenproject;

import org.openqa.selenium.By;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class EmailToFriend extends Utils {


    @Test
    public void sendemailtofriend() {



        System.setProperty("webdriver.gecko.driver", "src\\test\\Resources\\BrowserDriver\\geckodriver.exe");
        driver = new FirefoxDriver();
        driver.get("http://demo.nopcommerce.com");


        RegisterUser registeruser = new RegisterUser();
        registeruser.openBrowser();
        registeruser.verifyRegistrationComplete();

        SearchProduct searchProduct = new SearchProduct();
        searchProduct.searchProduct();

        String imgxpath = "//img[@src='http://demo.nopcommerce.com/images/thumbs/0000026_asus-n551jk-xo076h-laptop_415.jpeg']";
        clickElement(By.xpath(imgxpath));


        String emailpath=" (//input[@value= 'Email a friend'])";
        clickElement(By.xpath(emailpath));


        String email = "ameepatel.uk" + randomDate() + "@gmail.com";
        enterValue(By.id("FriendEmail"),email);

        String yoremail = "ameepiyush" + randomDate() + "@gmail.com";
        enterValue(By.id("YourEmailAddress"),yoremail);

        enterValue(By.id("PersonalMessage"),"This is nice product if you want to buy..hurry");

        String sendemailpath=" (//input[@value= 'Send email'])";
        clickElement(By.xpath(sendemailpath));

    }
}
