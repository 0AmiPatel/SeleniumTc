package com.automationtesting.mavenproject;

import org.openqa.selenium.By;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.internal.FindsByClassName;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;


import java.util.concurrent.TimeUnit;


public class BrowserSelector extends Utils {


    @Test
    public void openBrowser() {                            // method to open website in browser

        System.setProperty("webdriver.gecko.driver", "src\\test\\Resources\\BrowserDriver\\geckodriver.exe");   //seting geckodriver path required to open the browser.
        driver = new FirefoxDriver();                                                                 //created object of webdriver - firefox
        driver.get("http://demo.nopcommerce.com");


    }
}




