package com.automationtesting.mavenproject;

import org.openqa.selenium.By;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

public class RegisterUser extends Utils {


    @Test(priority =1)
    public void openBrowser() {                            // method to open website in browser

        System.setProperty("webdriver.gecko.driver", "src\\test\\Resources\\BrowserDriver\\geckodriver.exe");   //seting geckodriver path required to open the browser.
        driver = new FirefoxDriver();                                                                 //created object of webdriver - firefox
        driver.get("http://demo.nopcommerce.com");


        //instruct driver to open the registration page
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);        // wait command

        clickElement(By.linkText("Register"));


        //filling up registration Form

        clickElement(By.id("gender-female"));
        enterValue(By.id("FirstName"), "Ami");
        enterValue(By.id("LastName"), "Patel");
        String email = "ameepatel.uk" + randomDate() + "@gmail.com";
        enterValue(By.id("Email"), email);
        enterValue(By.id("Password"), "abc123");
        enterValue(By.id("ConfirmPassword"), "abc123");

        clickElement(By.id("register-button"));
    }

    @Test (priority =2)
    public void verifyRegistrationComplete(){

        //  Assert.assertTrue(driver.findElement(By.className("result")).isDisplayed(),"It is not displayed") ;

        //verify using Url
        String expectedUrl = "http://demo.nopcommerce.com/registerresult/1";  //expected url is taken from browser to verify
        String actualUrl = driver.getCurrentUrl();

        Assert.assertTrue(actualUrl.contains(expectedUrl),"actualUrl is not same as expected url");
        // driver.close();
    }
}
