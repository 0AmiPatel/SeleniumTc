package com.automationtesting.mavenproject;

import org.openqa.selenium.By;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

public class RegisterPageErrorMsg extends Utils {



    @Test
    public void verifyAllErrorMsgDisplayed() {


            System.setProperty("webdriver.gecko.driver", "src\\test\\Resources\\BrowserDriver\\geckodriver.exe");   //seting geckodriver path required to open the browser.
            driver = new FirefoxDriver();                                                                 //created object of webdriver - firefox
            driver.get("http://demo.nopcommerce.com");


            //instruct driver to open the registration page
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);        // wait command


        clickElement(By.linkText("Register"));
        clickElement(By.id("register-button"));

        String firstnameexpected = "First name is required.";
        // String fnpath= "//input[@id='FirstName']/span[2]/span";
        String fnpath="//input[@id='FirstName']//following::span[3]";

        String lastnameexpected = "Last name is required.";
//        String lnpath= "//input[@id='LastName']/span[2]/span";
        String lnpath="//input[@id='LastName']//following::span[3]";

      String emailexpected = "Email is required.";
       String epath= "//input[@id='Email']//following::span[3]";

        String pwdexpected = "Password is required.";
        String pwdpath = "//input[@id='Password']//following::span[3]";

        String confmpwdexpected = "Password is required.";
        String confmpwdpath = "//input[@id='ConfirmPassword']//following::span[3]";


        Assert.assertEquals(firstnameexpected,driver.findElement(By.xpath(fnpath)).getText());
       Assert.assertEquals(lastnameexpected,driver.findElement(By.xpath(lnpath)).getText());
       Assert.assertEquals(emailexpected,driver.findElement(By.xpath(epath)).getText());
        Assert.assertEquals(pwdexpected,driver.findElement(By.xpath(pwdpath)).getText());
        Assert.assertEquals(confmpwdexpected,driver.findElement(By.xpath(confmpwdpath)).getText());
    }


    @AfterClass
    public void closeBrowser(){

        driver.quit();
    }


      //method
//it should compare string returns in testsuite....with each elements.
//        public String getText(By by, String s){
//
//            driver.findElement(by).getText();
//            return s;
//}






}
