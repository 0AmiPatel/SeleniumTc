package com.automationtesting.mavenproject;

import org.openqa.selenium.WebDriver;

public class BasePage {

    //       //variable driver is set for Webdriver
    protected static WebDriver driver;

}
