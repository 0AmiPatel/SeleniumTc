package com.automationtesting.mavenproject;

import org.openqa.selenium.By;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

public class CompareTwoProducts extends Utils {

    @Test
    public void compareTwoProducts() {


        System.setProperty("webdriver.gecko.driver", "src\\test\\Resources\\BrowserDriver\\geckodriver.exe");   //seting geckodriver path required to open the browser.
        driver = new FirefoxDriver();                                                                 //created object of webdriver - firefox
        driver.get("http://demo.nopcommerce.com");


        //instruct driver to open the registration page
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

        clickElement(By.linkText("Computers"));

        clickElement(By.linkText("Desktops"));
        String additem = "(//input[@value='Add to compare list'])[1]";
        clickElement(By.xpath(additem));
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

        clickElement(By.linkText("Notebooks"));
        clickElement(By.xpath(additem));

        clickElement(By.linkText("product comparison"));

        String expectedurl = "http://demo.nopcommerce.com/compareproducts";
        String actualUrl = driver.getCurrentUrl();

        Assert.assertTrue(actualUrl.contains(expectedurl),"actualUrl is not same as expected url");





    }
}
