package com.automationtesting.mavenproject;

import org.openqa.selenium.By;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

public class ClearCompareList extends Utils {
    @Test
    public void compareTwoProducts() {

        BrowserSelector browserSelector = new BrowserSelector();
        browserSelector.openBrowser();

        CompareTwoProducts compareTwoProducts = new CompareTwoProducts();
        compareTwoProducts.compareTwoProducts();

        clickElement(By.linkText("Clear list"));


           //     String actualtext = "you have no items to compare";
              //  String expectedtext = driver.findElement(By.className("No-data")).getText();
                  Assert.assertTrue(driver.findElement(By.className("No-data")).isDisplayed(),"It is not displayed") ;


    }




    }
