package com.automationtesting.mavenproject;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

public class AddProducttoWishList extends Utils{

@Test
    public void verifyProductAddedtowishlist(){  // task: 4 - product should be added to wishlist

        clickElement(By.linkText("Electronics"));
        clickElement(By.linkText("Cell phones"));


        //   String s = "add-to-wishlist-button";
        //  clickElement(By.className(s));
        String clicktoadditem = "(//input[@value='Add to wishlist'])[1]";
        clickElement(By.xpath(clicktoadditem));
        Assert.assertTrue(driver.findElement(By.className("content")).isDisplayed(),"Item is not added to wishlist");
        Assert.assertEquals("(1)",driver.findElement(By.className("wishlist-qty")).getText());
        //Assert.assertEquals(true,driver.findElement(By.linkText("Wishlist")).isDisplayed());

    }


    @AfterClass
    public void closeBrowser(){

        //driver.quit();
    }
}
