package com.automationtesting.mavenproject;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

public class UserLogOut extends Utils {







    @Test
    public void verifyUserisAbletoLogOut(){     // task:3 - user should be able to logout Registrationpage



        RegisterUser registeruser = new RegisterUser();
        registeruser.openBrowser();
        registeruser.verifyRegistrationComplete();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

        // verify if log out option is available on top
        Assert.assertEquals(true,driver.findElement(By.linkText("Log out")).isDisplayed());

        // verify if user is able to click logout and log in displayed back after you logged out.
        clickElement(By.className("ico-logout"));
        String expectedLink1 = "Log in";
        String actualLinktext1 = driver.findElement(By.linkText("Log in")).getText();
        Assert.assertEquals(actualLinktext1,expectedLink1, "log in functionality is not verified");



    }
}
