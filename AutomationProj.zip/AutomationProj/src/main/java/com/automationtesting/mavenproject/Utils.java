package com.automationtesting.mavenproject;

import org.openqa.selenium.By;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Utils extends BasePage {          //child class of Baseclass (webdriver )


    public static void clickElement(By by){  // By is the class
        driver.findElement(by).click();         //driver will find element and click

    }

    public static void enterValue(By by,String text){

        driver.findElement(by).clear();
        driver.findElement(by).sendKeys(text);
    }



    public String randomDate() {
        DateFormat formatofdate = new SimpleDateFormat("ddMMyyHHmmss");
        return formatofdate.format(new Date());

    }


}

