import com.automationtesting.mavenproject.BrowserSelector;
import com.automationtesting.mavenproject.Utils;

public class TestSuite extends Utils {


}
